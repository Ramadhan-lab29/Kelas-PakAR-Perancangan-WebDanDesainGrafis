// Toggle class active
const hamburger = document.getElementById("hamburger-menu");
const nav = document.querySelector(".navbar-nav");

hamburger.addEventListener("click", () => {
  nav.classList.toggle("active");
});
